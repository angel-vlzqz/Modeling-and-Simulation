If you're running this file for the first time, make sure you have the 
correct dependencies installed.

Paste this snippet into your terminal to install onto your environment.

```
pip install matplotlib
pip install scipy
pip install math
pip install time
```

Once installed, you may choose to run the program through VSCode.
the result will be printed onto your terminal, and a new window will
appear showing the graph of the differential equation.
